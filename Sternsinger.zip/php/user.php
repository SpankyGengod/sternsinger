<?php
  include("card.php");
  $content = '<div class="container">
                <br><br>
                <div class="row">
                  '.card("col-sm-6", "Tag 1", "AKJSJDASKDJLSAJDKSAJLDKSAJDK").'
                  '.card("col-sm-6", "Tag 2", "MAKSDNASDKLSALDKSADMKSAMDKSAMDLKSAMD").'
                </div>
                <br>
                <div class="row">
                  '.card("col-sm-6", "Tag 3", "ASKDSAMDKASMDKSAMDKSAMDMKSADMSAKDMSKA").'
                  '.card("col-sm-6", "Tag 4", "AMSKDMSAKDMSAKDMKSAMDKSAMDMKSA").'
                </div>
              </div>';
?>
