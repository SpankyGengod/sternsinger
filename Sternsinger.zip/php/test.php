<?php
  include ("http://gengod.net/dash/php/dbsettins.php");
  var_dump(get_defined_vars());
?>
